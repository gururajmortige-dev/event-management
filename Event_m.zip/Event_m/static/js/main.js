/**
 * EventPulse Front-end Interactivity & UI Controller
 */

document.addEventListener("DOMContentLoaded", () => {
  // 1. Dynamic Accents & Progress Bars (Replaces inline style expressions)
  document.querySelectorAll("[data-accent]").forEach((el) => {
    const accent = el.getAttribute("data-accent") || "#6366f1";
    if (el.classList.contains("card-banner")) {
      el.style.background = `linear-gradient(135deg, ${accent}cc, #1e1b4b)`;
    } else if (el.classList.contains("event-hero-card")) {
      el.style.borderTop = `5px solid ${accent}`;
    }
  });

  document.querySelectorAll("[data-width]").forEach((el) => {
    const width = el.getAttribute("data-width") || "0";
    el.style.width = `${Math.min(100, Math.max(0, parseInt(width, 10)))}%`;
  });

  // 2. Toast Notifications & Close Handlers
  const toasts = document.querySelectorAll(".toast");
  toasts.forEach((toast) => {
    // Auto-dismiss after 5s
    setTimeout(() => {
      toast.style.transition = "opacity 0.5s ease, transform 0.5s ease";
      toast.style.opacity = "0";
      toast.style.transform = "translateX(50px)";
      setTimeout(() => toast.remove(), 500);
    }, 5000);

    const closeBtn = toast.querySelector(".toast-close");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => toast.remove());
    }
  });

  // 3. Confirm Delete Form Interceptor
  document.querySelectorAll(".confirm-delete-form").forEach((form) => {
    form.addEventListener("submit", (e) => {
      const msg = form.getAttribute("data-confirm-message") || "Are you sure you want to proceed?";
      if (!window.confirm(msg)) {
        e.preventDefault();
      }
    });
  });

  // 4. View Toggle (Grid vs List)
  const gridBtn = document.getElementById("grid-view-btn");
  const listBtn = document.getElementById("list-view-btn");
  const eventsContainer = document.getElementById("events-container");

  if (gridBtn && listBtn && eventsContainer) {
    const savedView = localStorage.getItem("event_view_mode") || "grid";
    if (savedView === "list") {
      eventsContainer.classList.add("list-view");
      listBtn.classList.add("active");
      gridBtn.classList.remove("active");
    }

    gridBtn.addEventListener("click", () => {
      eventsContainer.classList.remove("list-view");
      gridBtn.classList.add("active");
      listBtn.classList.remove("active");
      localStorage.setItem("event_view_mode", "grid");
    });

    listBtn.addEventListener("click", () => {
      eventsContainer.classList.add("list-view");
      listBtn.classList.add("active");
      gridBtn.classList.remove("active");
      localStorage.setItem("event_view_mode", "list");
    });
  }

  // 5. Quick RSVP Modal (Dashboard)
  const quickRsvpModal = document.getElementById("quick-rsvp-modal");
  const quickRsvpForm = document.getElementById("quick-rsvp-form");
  const modalEventTitle = document.getElementById("modal-event-title");
  const closeModalBtn = document.getElementById("close-modal-btn");
  const modalCancelBtn = document.getElementById("modal-cancel-btn");

  if (quickRsvpModal && quickRsvpForm) {
    document.querySelectorAll(".open-quick-rsvp-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const eventId = btn.getAttribute("data-event-id");
        const eventTitle = btn.getAttribute("data-event-title");

        quickRsvpForm.action = `/events/${eventId}/register`;
        if (modalEventTitle) {
          modalEventTitle.textContent = `Reserve: ${eventTitle}`;
        }
        quickRsvpModal.classList.add("open");
      });
    });

    const hideModal = () => quickRsvpModal.classList.remove("open");
    if (closeModalBtn) closeModalBtn.addEventListener("click", hideModal);
    if (modalCancelBtn) modalCancelBtn.addEventListener("click", hideModal);

    quickRsvpModal.addEventListener("click", (e) => {
      if (e.target === quickRsvpModal) hideModal();
    });
  }

  // 6. Digital Ticket Pass Modal & Print
  const ticketModal = document.getElementById("ticket-modal");
  const closeTicketBtn = document.getElementById("close-ticket-btn");
  const ticketDoneBtn = document.getElementById("ticket-done-btn");
  const printPassBtn = document.getElementById("print-pass-btn");

  if (printPassBtn) {
    printPassBtn.addEventListener("click", () => window.print());
  }

  if (ticketModal) {
    document.querySelectorAll(".view-ticket-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-id") || "";
        const name = btn.getAttribute("data-name") || "";
        const ticket = btn.getAttribute("data-ticket") || "Regular";
        const event = btn.getAttribute("data-event") || "";
        const date = btn.getAttribute("data-date") || "";
        const time = btn.getAttribute("data-time") || "";
        const location = btn.getAttribute("data-location") || "";

        const passName = document.getElementById("pass-name");
        const passId = document.getElementById("pass-id");
        const passType = document.getElementById("pass-type");
        const passEvent = document.getElementById("pass-event");
        const passDateTime = document.getElementById("pass-date-time");
        const passLocation = document.getElementById("pass-location");

        if (passName) passName.textContent = name;
        if (passId) passId.textContent = id.toUpperCase();
        if (passType) passType.textContent = ticket;
        if (passEvent) passEvent.textContent = event;
        if (passDateTime) passDateTime.textContent = `${date} • ${time}`;
        if (passLocation) passLocation.textContent = location;

        ticketModal.classList.add("open");
      });
    });

    const hideTicket = () => ticketModal.classList.remove("open");
    if (closeTicketBtn) closeTicketBtn.addEventListener("click", hideTicket);
    if (ticketDoneBtn) ticketDoneBtn.addEventListener("click", hideTicket);

    ticketModal.addEventListener("click", (e) => {
      if (e.target === ticketModal) hideTicket();
    });
  }

  // 7. Live Countdown Timer on Event Detail Page
  const countdownWidget = document.getElementById("countdown-widget");
  if (countdownWidget) {
    const eventDate = countdownWidget.getAttribute("data-date");
    let eventTime = (countdownWidget.getAttribute("data-time") || "10:00 AM").trim();

    // If time is a range like "10:00 AM - 04:00 PM", take the start time
    if (eventTime.includes("-")) {
      eventTime = eventTime.split("-")[0].trim();
    }

    // Try parsing date string robustly
    let targetDate = new Date(`${eventDate} ${eventTime}`).getTime();
    if (isNaN(targetDate)) {
      targetDate = new Date(`${eventDate}T10:00:00`).getTime();
    }

    const daysEl = document.getElementById("cd-days");
    const hoursEl = document.getElementById("cd-hours");
    const minsEl = document.getElementById("cd-mins");
    const secsEl = document.getElementById("cd-secs");

    const updateCountdown = () => {
      const now = new Date().getTime();
      const distance = targetDate - now;

      if (distance < 0 || isNaN(targetDate)) {
        if (daysEl) daysEl.textContent = "00";
        if (hoursEl) hoursEl.textContent = "00";
        if (minsEl) minsEl.textContent = "00";
        if (secsEl) secsEl.textContent = "00";
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      if (daysEl) daysEl.textContent = String(days).padStart(2, "0");
      if (hoursEl) hoursEl.textContent = String(hours).padStart(2, "0");
      if (minsEl) minsEl.textContent = String(minutes).padStart(2, "0");
      if (secsEl) secsEl.textContent = String(seconds).padStart(2, "0");
    };

    updateCountdown();
    setInterval(updateCountdown, 1000);
  }

  // 8. Color Swatch Picker on Event Form
  const colorInput = document.getElementById("accent_color");
  const swatches = document.querySelectorAll(".color-swatch");
  if (colorInput && swatches.length > 0) {
    swatches.forEach((swatch) => {
      swatch.addEventListener("click", () => {
        const color = swatch.getAttribute("data-color");
        if (color) colorInput.value = color;
      });
    });
  }

  // 9. Instant Filter on Attendees Table (Local client-side search)
  const attendeeSearch = document.getElementById("attendee-table-search");
  const attendeesTable = document.getElementById("attendees-table");
  if (attendeeSearch && attendeesTable) {
    attendeeSearch.addEventListener("input", (e) => {
      const term = e.target.value.toLowerCase().trim();
      const rows = attendeesTable.querySelectorAll("tbody tr.attendee-row");

      rows.forEach((row) => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(term) ? "" : "none";
      });
    });
  }

  // 10. Event Filter Dropdown Auto-submit on Directory
  const eventFilterSelect = document.getElementById("event-filter-select");
  if (eventFilterSelect) {
    eventFilterSelect.addEventListener("change", function () {
      if (this.form) this.form.submit();
    });
  }
});
