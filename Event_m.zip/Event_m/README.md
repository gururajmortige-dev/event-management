# EventPulse - Local Event Management System ⚡

A modern, full-featured **Event Management System** built with **Python & Flask**. Designed for seamless local execution with **zero database configuration** (stores and persists data locally via clean JSON records in `data/events.json`).

---

## 🌟 Key Features

- **Local-First & Zero DB Setup**: Runs immediately on your local machine without needing MySQL, PostgreSQL, SQLite migrations, or ORMs.
- **Rich Modern UI**: Dark glassmorphic design system, vibrant accent gradients, responsive layout, and smooth micro-animations.
- **Real-Time Capacity Tracker**: Progress meters with color-coded alerts (Open, Filling Fast, Sold Out) and automatic registration limits.
- **Full Event Lifecycle (CRUD)**:
  - Create, view, edit, and delete events.
  - Custom category tagging & customizable accent branding color.
  - Date, time, location/venue, and capacity configuration.
- **Attendee & RSVP Management**:
  - Quick RSVP modal directly from the dashboard or event detail page.
  - Ticket types: *Regular*, *VIP Priority Pass*, and *Student Discount*.
  - Duplicate email protection per event.
  - Capacity cap protection.
- **Digital Event Pass Preview & Print**:
  - Interactive digital pass popup with simulated barcode, ticket ID, and event credentials.
  - One-click print / PDF export option.
- **CSV Data Export**:
  - Export single event attendee roster to `.csv`.
  - Export master attendee roster across all events to `.csv`.
- **Live Search & Filter**:
  - Filter events by status (*All*, *Upcoming*, *Past*).
  - Filter by category pills.
  - Live client-side search across attendee tables.
- **Live Countdown Timer**:
  - Real-time countdown widget to the event date and time.
- **Reset Demo Data**:
  - Built-in one-click restore button in the footer to reset sample events at any time.

---

## 📁 Project Structure

```
Event_m/
├── app.py                  # Main Flask application & routes
├── storage.py              # Local JSON data engine & CRUD operations
├── requirements.txt        # Minimal dependency list (Flask)
├── README.md               # Project documentation
├── data/
│   └── events.json         # Persistent local storage (auto-created)
├── static/
│   ├── css/
│   │   └── style.css       # Complete custom glassmorphism design system
│   └── js/
│       └── main.js         # Modals, countdown, toasts, search filtering
└── templates/
    ├── base.html           # Master layout with navbar, alerts & footer
    ├── index.html          # Dashboard & events discovery catalog
    ├── event_detail.html   # Event page, countdown, RSVP & attendee table
    ├── event_form.html     # Event creation & editing form
    └── attendees.html      # Master attendee directory & export
```

---

## 🚀 How to Run Locally

### 1. (Optional) Activate your Python Environment
Make sure you have Python 3.8+ installed.

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Start the Local Server
```bash
python app.py
```

### 4. Open in Browser
Open your browser and navigate to:
```
http://127.0.0.1:5000
```
