import csv
import io
from datetime import datetime, date
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    Response,
    jsonify
)
from storage import db_store

app = Flask(__name__)
app.secret_key = "super-secret-local-event-manager-key-2026"


def calculate_event_stats(events):
    today_str = date.today().isoformat()
    total_events = len(events)
    total_capacity = sum(e.get("capacity", 0) for e in events)
    total_attendees = sum(len(e.get("attendees", [])) for e in events)
    
    upcoming_events = [e for e in events if e.get("date", "") >= today_str]
    past_events = [e for e in events if e.get("date", "") < today_str]
    
    occupancy_rate = 0
    if total_capacity > 0:
        occupancy_rate = round((total_attendees / total_capacity) * 100, 1)

    return {
        "total_events": total_events,
        "total_attendees": total_attendees,
        "upcoming_count": len(upcoming_events),
        "past_count": len(past_events),
        "total_capacity": total_capacity,
        "occupancy_rate": occupancy_rate
    }


@app.context_processor
def inject_global_data():
    all_events = db_store.get_all()
    categories = sorted(list(set(e.get("category", "General") for e in all_events)))
    today_str = date.today().isoformat()
    return dict(categories=categories, today_str=today_str)


@app.route("/")
def home():
    query = request.args.get("q", "").strip().lower()
    selected_category = request.args.get("category", "").strip()
    status_filter = request.args.get("status", "all").strip().lower()

    all_events = db_store.get_all()
    today_str = date.today().isoformat()

    filtered_events = []
    for e in all_events:
        # Category filter
        if selected_category and e.get("category") != selected_category:
            continue

        # Status filter
        event_date = e.get("date", "")
        if status_filter == "upcoming" and event_date < today_str:
            continue
        if status_filter == "past" and event_date >= today_str:
            continue
        if status_filter == "today" and event_date != today_str:
            continue

        # Query search filter
        if query:
            searchable_text = f"{e.get('title', '')} {e.get('location', '')} {e.get('description', '')} {e.get('organizer', '')}".lower()
            if query not in searchable_text:
                continue

        filtered_events.append(e)

    stats = calculate_event_stats(all_events)

    return render_template(
        "index.html",
        events=filtered_events,
        stats=stats,
        query=query,
        selected_category=selected_category,
        status_filter=status_filter
    )


@app.route("/events/new", methods=["GET", "POST"])
def create_event():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        event_date = request.form.get("date", "").strip()
        location = request.form.get("location", "").strip()
        capacity = request.form.get("capacity", "").strip()

        if not title or not event_date or not location:
            flash("Please fill in all mandatory fields (Title, Date, Location).", "error")
            return render_template("event_form.html", event=request.form, is_edit=False)

        try:
            capacity_val = int(capacity) if capacity else 50
            if capacity_val <= 0:
                raise ValueError()
        except ValueError:
            flash("Capacity must be a positive integer greater than 0.", "error")
            return render_template("event_form.html", event=request.form, is_edit=False)

        new_event = db_store.add_event(request.form)
        flash(f"Event '{new_event['title']}' created successfully!", "success")
        return redirect(url_for("event_detail", event_id=new_event["id"]))

    return render_template("event_form.html", event={}, is_edit=False)


@app.route("/events/<event_id>")
def event_detail(event_id):
    event = db_store.get_by_id(event_id)
    if not event:
        flash("Event not found.", "error")
        return redirect(url_for("home"))

    attendees = event.get("attendees", [])
    capacity = event.get("capacity", 50)
    registered_count = len(attendees)
    spots_left = max(0, capacity - registered_count)
    fill_pct = min(100, round((registered_count / capacity) * 100)) if capacity > 0 else 0

    return render_template(
        "event_detail.html",
        event=event,
        attendees=attendees,
        spots_left=spots_left,
        fill_pct=fill_pct
    )


@app.route("/events/<event_id>/edit", methods=["GET", "POST"])
def edit_event(event_id):
    event = db_store.get_by_id(event_id)
    if not event:
        flash("Event not found.", "error")
        return redirect(url_for("home"))

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        event_date = request.form.get("date", "").strip()
        location = request.form.get("location", "").strip()
        capacity = request.form.get("capacity", "").strip()

        if not title or not event_date or not location:
            flash("Please fill in all mandatory fields.", "error")
            return render_template("event_form.html", event=request.form, is_edit=True, event_id=event_id)

        try:
            capacity_val = int(capacity) if capacity else 50
            if capacity_val < len(event.get("attendees", [])):
                flash(f"Capacity cannot be smaller than current attendee count ({len(event.get('attendees', []))}).", "error")
                return render_template("event_form.html", event=request.form, is_edit=True, event_id=event_id)
        except ValueError:
            flash("Capacity must be a positive integer.", "error")
            return render_template("event_form.html", event=request.form, is_edit=True, event_id=event_id)

        db_store.update_event(event_id, request.form)
        flash("Event updated successfully!", "success")
        return redirect(url_for("event_detail", event_id=event_id))

    return render_template("event_form.html", event=event, is_edit=True, event_id=event_id)


@app.route("/events/<event_id>/delete", methods=["POST"])
def delete_event(event_id):
    event = db_store.get_by_id(event_id)
    if event:
        db_store.delete_event(event_id)
        flash(f"Event '{event['title']}' deleted successfully.", "info")
    else:
        flash("Event not found.", "error")
    return redirect(url_for("home"))


@app.route("/events/<event_id>/register", methods=["POST"])
def register_attendee(event_id):
    event = db_store.get_by_id(event_id)
    if not event:
        flash("Event not found.", "error")
        return redirect(url_for("home"))

    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip()

    if not name or not email:
        flash("Attendee name and email are required.", "error")
        return redirect(url_for("event_detail", event_id=event_id))

    success, result = db_store.add_attendee(event_id, request.form)
    if success:
        flash(f"Registration confirmed! Welcome aboard, {name}.", "success")
    else:
        flash(result, "error")

    return redirect(url_for("event_detail", event_id=event_id))


@app.route("/events/<event_id>/attendees/<attendee_id>/delete", methods=["POST"])
def remove_attendee(event_id, attendee_id):
    success = db_store.remove_attendee(event_id, attendee_id)
    if success:
        flash("Attendee reservation cancelled.", "info")
    else:
        flash("Attendee could not be removed.", "error")
    return redirect(url_for("event_detail", event_id=event_id))


@app.route("/attendees")
def all_attendees():
    query = request.args.get("q", "").strip().lower()
    event_filter = request.args.get("event_id", "").strip()
    all_atts = db_store.get_all_attendees()
    all_events = db_store.get_all()

    filtered = []
    for att in all_atts:
        if event_filter and str(att.get("event_id")) != event_filter:
            continue
        if query:
            searchable = f"{att.get('name', '')} {att.get('email', '')} {att.get('event_title', '')}".lower()
            if query not in searchable:
                continue
        filtered.append(att)

    return render_template(
        "attendees.html",
        attendees=filtered,
        events=all_events,
        query=query,
        selected_event=event_filter
    )


@app.route("/events/<event_id>/export-csv")
def export_event_csv(event_id):
    event = db_store.get_by_id(event_id)
    if not event:
        flash("Event not found", "error")
        return redirect(url_for("home"))

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Ticket ID", "Full Name", "Email Address", "Ticket Type", "Registered Date/Time", "Special Notes"])

    for att in event.get("attendees", []):
        writer.writerow([
            att.get("id"),
            att.get("name"),
            att.get("email"),
            att.get("ticket_type"),
            att.get("registered_at"),
            att.get("notes")
        ])

    sanitized_title = "".join(c for c in event.get("title", "event") if c.isalnum() or c in (" ", "_", "-")).rstrip()
    filename = f"Attendees_{sanitized_title}.csv"

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": f"attachment; filename={filename}"}
    )


@app.route("/attendees/export-csv")
def export_all_attendees_csv():
    attendees = db_store.get_all_attendees()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Event ID", "Event Title", "Event Date", "Attendee ID", "Name", "Email", "Ticket Type", "Registered At"])

    for att in attendees:
        writer.writerow([
            att.get("event_id"),
            att.get("event_title"),
            att.get("event_date"),
            att.get("id"),
            att.get("name"),
            att.get("email"),
            att.get("ticket_type"),
            att.get("registered_at")
        ])

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=Master_Attendees_List.csv"}
    )


@app.route("/reset-demo", methods=["POST"])
def reset_demo():
    db_store.reset_demo_data()
    flash("Demo database has been successfully reset to sample data!", "info")
    return redirect(url_for("home"))


@app.route("/api/events")
def api_events():
    return jsonify(db_store.get_all())


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print(">> Event Management System running on http://127.0.0.1:5000")
    print("=" * 60 + "\n")
    app.run(debug=True, host="127.0.0.1", port=5000)