"""
Local JSON-based Data Storage for Event Management System.
Requires no external database, SQLite, or ORM drivers.
Data is persisted to data/events.json.
"""

import json
import os
import uuid
from datetime import datetime, date

DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
DATA_FILE = os.path.join(DATA_DIR, "events.json")


def _ensure_data_dir():
    if not os.path.exists(DATA_DIR):
        os.makedirs(DATA_DIR, exist_ok=True)


def _safe_int(val, default=50):
    try:
        parsed = int(val)
        return parsed if parsed > 0 else default
    except (ValueError, TypeError):
        return default


def _get_default_seed():
    today = date.today().isoformat()
    return [
        {
            "id": "ev-101",
            "title": "Global Tech & AI Summit 2026",
            "category": "Technology",
            "date": "2026-11-20",
            "time": "10:00 AM",
            "location": "Convention Center, Grand Hall (Silicon Valley)",
            "capacity": 150,
            "description": "Explore the frontier of Generative AI, autonomous agents, quantum computing, and ethical frameworks with global leaders and founders.",
            "organizer": "TechNext Innovations",
            "organizer_email": "hello@technext.org",
            "accent_color": "#6366f1",
            "created_at": today,
            "attendees": [
                {
                    "id": "att-101",
                    "name": "Alex Morgan",
                    "email": "alex.morgan@example.com",
                    "ticket_type": "VIP Pass",
                    "registered_at": today,
                    "notes": "Keynote speaker guest"
                },
                {
                    "id": "att-102",
                    "name": "Sarah Chen",
                    "email": "sarah.chen@techcorp.io",
                    "ticket_type": "Regular",
                    "registered_at": today,
                    "notes": "Interested in Agentic AI workshops"
                },
                {
                    "id": "att-103",
                    "name": "David Kumar",
                    "email": "dkumar@cloudlabs.dev",
                    "ticket_type": "Student",
                    "registered_at": today,
                    "notes": ""
                }
            ]
        },
        {
            "id": "ev-102",
            "title": "Neon Sunset Indie Music Festival",
            "category": "Music & Arts",
            "date": "2026-12-05",
            "time": "05:00 PM",
            "location": "Skyline Amphitheater, Waterfront Park",
            "capacity": 80,
            "description": "An evening of dreamy synth-wave, indie rock acoustics, gourmet food trucks, and laser light installations under the open sky.",
            "organizer": "VibeHouse Collective",
            "organizer_email": "booking@vibehouse.live",
            "accent_color": "#ec4899",
            "created_at": today,
            "attendees": [
                {
                    "id": "att-104",
                    "name": "Liam Vance",
                    "email": "liam.vance@musicfan.net",
                    "ticket_type": "Regular",
                    "registered_at": today,
                    "notes": "Bringing acoustic guitar"
                },
                {
                    "id": "att-105",
                    "name": "Elena Rostova",
                    "email": "elena.r@soundwave.fm",
                    "ticket_type": "VIP Pass",
                    "registered_at": today,
                    "notes": "Press badge requested"
                }
            ]
        },
        {
            "id": "ev-103",
            "title": "Design Systems & UI/UX Masterclass",
            "category": "Design",
            "date": "2026-10-28",
            "time": "02:00 PM",
            "location": "Virtual Hub / Design Studio B",
            "capacity": 45,
            "description": "Hands-on workshop detailing component tokens, fluid responsive layouts, micro-interactions, and accessibility standards for modern web applications.",
            "organizer": "PixelCraft Academy",
            "organizer_email": "mentor@pixelcraft.studio",
            "accent_color": "#06b6d4",
            "created_at": today,
            "attendees": [
                {
                    "id": "att-106",
                    "name": "Marcus Wright",
                    "email": "marcus.w@productcraft.design",
                    "ticket_type": "Regular",
                    "registered_at": today,
                    "notes": "Figma power user"
                }
            ]
        },
        {
            "id": "ev-104",
            "title": "Green Earth Climate & Clean Energy Expo",
            "category": "Sustainability",
            "date": "2026-11-12",
            "time": "09:30 AM",
            "location": "Eco Pavilion, Green Gardens",
            "capacity": 100,
            "description": "Showcasing next-generation solar tech, battery breakthroughs, circular economy startups, and grassroots community green initiatives.",
            "organizer": "EarthFirst Initiative",
            "organizer_email": "action@earthfirst.earth",
            "accent_color": "#10b981",
            "created_at": today,
            "attendees": []
        }
    ]


class EventStorage:
    def __init__(self):
        _ensure_data_dir()
        if not os.path.exists(DATA_FILE):
            self.save_all(_get_default_seed())

    def _load_raw(self):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else _get_default_seed()
        except Exception:
            return _get_default_seed()

    def save_all(self, data):
        _ensure_data_dir()
        temp_file = DATA_FILE + ".tmp"
        with open(temp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(temp_file, DATA_FILE)

    def get_all(self):
        events = self._load_raw()
        # Sort by date ascending safely
        events.sort(key=lambda e: (e.get("date") or "", e.get("time") or ""))
        return events

    def get_by_id(self, event_id):
        events = self._load_raw()
        for e in events:
            if str(e.get("id")) == str(event_id):
                return e
        return None

    def add_event(self, data):
        events = self._load_raw()
        new_id = f"ev-{uuid.uuid4().hex[:6]}"
        event = {
            "id": new_id,
            "title": data.get("title", "").strip(),
            "category": data.get("category", "General").strip() or "General",
            "date": data.get("date", "").strip(),
            "time": data.get("time", "10:00 AM").strip() or "10:00 AM",
            "location": data.get("location", "").strip(),
            "capacity": _safe_int(data.get("capacity"), 50),
            "description": data.get("description", "").strip(),
            "organizer": data.get("organizer", "Event Host").strip() or "Event Host",
            "organizer_email": data.get("organizer_email", "").strip(),
            "accent_color": data.get("accent_color", "#6366f1").strip() or "#6366f1",
            "created_at": date.today().isoformat(),
            "attendees": []
        }
        events.append(event)
        self.save_all(events)
        return event

    def update_event(self, event_id, data):
        events = self._load_raw()
        for idx, e in enumerate(events):
            if str(e.get("id")) == str(event_id):
                events[idx]["title"] = data.get("title", e.get("title")).strip()
                events[idx]["category"] = data.get("category", e.get("category")).strip()
                events[idx]["date"] = data.get("date", e.get("date")).strip()
                events[idx]["time"] = data.get("time", e.get("time")).strip()
                events[idx]["location"] = data.get("location", e.get("location")).strip()
                events[idx]["capacity"] = _safe_int(data.get("capacity"), e.get("capacity", 50))
                events[idx]["description"] = data.get("description", e.get("description")).strip()
                events[idx]["organizer"] = data.get("organizer", e.get("organizer")).strip()
                events[idx]["organizer_email"] = data.get("organizer_email", e.get("organizer_email")).strip()
                if data.get("accent_color"):
                    events[idx]["accent_color"] = data.get("accent_color").strip()
                self.save_all(events)
                return events[idx]
        return None

    def delete_event(self, event_id):
        events = self._load_raw()
        initial_len = len(events)
        events = [e for e in events if str(e.get("id")) != str(event_id)]
        if len(events) != initial_len:
            self.save_all(events)
            return True
        return False

    def add_attendee(self, event_id, attendee_data):
        events = self._load_raw()
        for e in events:
            if str(e.get("id")) == str(event_id):
                attendees = e.setdefault("attendees", [])
                
                # Check capacity
                capacity = _safe_int(e.get("capacity"), 50)
                if len(attendees) >= capacity:
                    return False, "This event is at maximum capacity!"
                
                # Check duplicate email
                email = attendee_data.get("email", "").strip().lower()
                for att in attendees:
                    if att.get("email", "").strip().lower() == email:
                        return False, "A registration with this email already exists for this event!"

                new_att = {
                    "id": f"att-{uuid.uuid4().hex[:6]}",
                    "name": attendee_data.get("name", "").strip(),
                    "email": attendee_data.get("email", "").strip(),
                    "ticket_type": attendee_data.get("ticket_type", "Regular"),
                    "registered_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "notes": attendee_data.get("notes", "").strip()
                }
                attendees.append(new_att)
                self.save_all(events)
                return True, new_att
        return False, "Event not found"

    def remove_attendee(self, event_id, attendee_id):
        events = self._load_raw()
        for e in events:
            if str(e.get("id")) == str(event_id):
                initial_count = len(e.get("attendees", []))
                e["attendees"] = [att for att in e.get("attendees", []) if str(att.get("id")) != str(attendee_id)]
                if len(e["attendees"]) != initial_count:
                    self.save_all(events)
                    return True
        return False

    def get_all_attendees(self):
        events = self._load_raw()
        results = []
        for e in events:
            for att in e.get("attendees", []):
                results.append({
                    **att,
                    "event_id": e.get("id"),
                    "event_title": e.get("title"),
                    "event_date": e.get("date"),
                    "event_location": e.get("location")
                })
        return results

    def reset_demo_data(self):
        seed = _get_default_seed()
        self.save_all(seed)
        return seed


# Singleton instance
db_store = EventStorage()
